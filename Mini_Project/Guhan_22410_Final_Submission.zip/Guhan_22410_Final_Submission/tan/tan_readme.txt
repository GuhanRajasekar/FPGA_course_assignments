The top file is "cordic_tan_dac_top.v" and the corresponding test bench file is "cordic_tan_dac_top_tb.v".
The constraints file is titled "cordic_tan_dac_top_constraints.xdc".

To view the waveforms in Vivado, Radix must be set to "Unsigned Decimal" and Waveform Type must be chosen as "Analog".