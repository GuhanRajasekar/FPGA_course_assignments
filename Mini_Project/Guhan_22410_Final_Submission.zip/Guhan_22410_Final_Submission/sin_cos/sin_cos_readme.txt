The top file is titled "cordic_sin_cos_top.v" and the corresponding test bench file is "cordic_sin_cos_top_tb.v".
The modules in the other files are instantiated from the top module.

To view the simulation results in vivado, we need to set radix to "Unsigned Decimal" and choose waveform type as "Analog".